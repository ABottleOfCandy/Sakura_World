<?php


    //数据库区

    $sql_host = 'localhost';    //数据库地址


    $sql_username = 'root';   //数据库账号


    $sql_password = 'root';     //数据库密码

    
    $sql_dbname = 'sakura';     //数据库库名

    $sql_formname = 'sakura';    //数据表名


    //跳转设置

    $main_page = 'https://login.wdsj.games/';   //主页


    //加密方式

    $secret_addr = 'secret'//我们在登陆验证时采用哈希MD5算法 为保障数据安全须在验证时在验证字符串前加入加密字符串
?>